    
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//class làm nhiệm vụ chuẩn hóa file

public class readFile {

// đọc từng dòng của file lưu vào trong String
    static String convertFileToString ( File f) {
        String str ="";
        try {
            String temp;
            BufferedReader br = new BufferedReader(new FileReader(f));
            while((temp = br.readLine())!= null) {
                str += temp + "\n";
            }
        } catch (IOException e ) {
            System.out.println(e);
        }
        return str;
    }

//xóa comment,
    static String handleFile( String text ) {
        String replace = "";
        
        String regex0 = "\\\\\"";
        Pattern p0 = Pattern.compile(regex0);//Tạo đối tượng là regex0
        Matcher m0 = p0.matcher(text);// so khớp với đoạn text
        text = m0.replaceAll(replace);//thay thế kí tự sau //
              
        String regex1 = "\"(.*?)\"";
        Pattern p1 = Pattern.compile(regex1);
        Matcher m1 = p1.matcher(text);
        text = m1.replaceAll(replace);
        
        String regex2 = "//.*\n";
        Pattern p2 = Pattern.compile(regex2);
        Matcher m2 = p2.matcher(text);
        text = m2.replaceAll(replace);
        
        
        String regex3 = "(/\\*(.*\n)*?.*\\*/)";
        Pattern p3 = Pattern.compile(regex3);
        Matcher m3 = p3.matcher(text);
        text = m3.replaceAll(replace);

        // xóa đoạn code return, new
        String regex4 ="(return|new)";
        Pattern p4= Pattern.compile(regex4);
        Matcher m4 = p4.matcher(text);
        text= m4.replaceAll(replace);
        String regex5 ="=.*?(?=;)";
        Pattern p5= Pattern.compile(regex5);
        Matcher m5 = p5.matcher(text);
        text= m5.replaceAll(replace);
       
        String regex6 ="'[{}]'";
        Pattern p6= Pattern.compile(regex6);
        Matcher m6 = p6.matcher(text);
        text= m6.replaceAll(replace);
        //xóa phần khởi tạo của biến
        String regex7 ="=.*?(?=,)";
        Pattern p7= Pattern.compile(regex7);
        Matcher m7 = p7.matcher(text);
        text= m7.replaceAll(replace);
             
        return text;
        
    }
    
}
