
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;
interface Paintable{
    public void paint(JComponent parent, Graphics2D g2);
    public boolean contains(Point p);
    public void moveTo(Point2D p);
    public Rectangle2D getBounds();
}
public class drawShape implements Paintable {
    private static final long serialVersionUID = 1L;
    private MemberInfo mem;
    private int x;
    private int y;
    private int width;
    private int height;
    private Rectangle2D bound;
    private final Font a = new Font("",Font.BOLD,10);
    public drawShape(MemberInfo a,int b,int c){
        mem = a;
        x = b;
        y = c;
        width =  findMaxWidth(a.getClassName(), a.getMethods(), a.getVariables());
        height = 20 + findMaxHeight(a.getMethods()) + findMaxHeight(a.getVariables());
        bound = new Rectangle2D.Double(b,c,findMaxWidth(a.getClassName(), a.getMethods(), a.getVariables()),20 + findMaxHeight(a.getMethods()) + findMaxHeight(a.getVariables()));
        
    }
    @Override
    public boolean contains(Point p){
        return bound.contains(p);
    }
    @Override
    public void moveTo(Point2D p){
        bound = new Rectangle2D.Double(p.getX(),p.getY(),findMaxWidth(mem.getClassName(), mem.getMethods(), mem.getVariables()),20 + findMaxHeight(mem.getMethods()) + findMaxHeight(mem.getVariables()));
    }
    @Override
    public Rectangle2D getBounds(){
        return bound;
    }
    @Override
    public void paint(JComponent parent,Graphics2D g){
        Graphics2D g2 = (Graphics2D) g.create();
        g2.translate(bound.getX(), bound.getY());
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
        g2.setColor(Color.white);
        FontMetrics fm = g.getFontMetrics();
        g2.fill3DRect(0 , 0, width , 30, false);    
       
        // phần tên lớp
        g2.setColor(Color.red);
        g2.setFont(a);
        g2.drawString(mem.getClassName(),(width - fm.stringWidth(mem.getClassName()))/2,(30 - fm.getHeight())/2 + fm.getAscent() );  
        // phần tên biến
        g2.setColor(Color.white);
        g2.fill3DRect(0 ,30, width , findMaxHeight(mem.getVariables()), true);    
        g2.setColor(Color.BLACK);
        g2.setFont(a);
        for(int i = 0; i < mem.getVariables().size();i++){
            g2.drawString(mem.getVariables().get(i).getFeature(),5 ,30 + fm.getAscent()*(i + 1) );  
        }
        //Phần tên phương thức
        g2.setColor(Color.white);
        g2.fill3DRect(0, 30 + findMaxHeight(mem.getVariables()), width ,findMaxHeight(mem.getMethods()) , true);    
        g2.setColor(Color.blue);
        g2.setFont(a);
        for(int i = 0; i < mem.getMethods().size();i++){
            g2.drawString(mem.getMethods().get(i).getFeature(),5 ,30 + findMaxHeight(mem.getVariables()) + fm.getAscent()*(i + 1) );  
        }
        g2.dispose();
    }
    // vẽ kích cỡ phù hợp cho các thông tin của lớp
    public int findMaxWidth(String a,ArrayList<Expression> b,ArrayList<Expression> c){
        int max = (a.length() <= Max(b))? Max(b):a.length();
        return (max <= Max(c))? Max(c)*6:max * 6;
    }
    //kích thước max của bảng
    public int Max(ArrayList<Expression> b) {
        if (b.size() > 0 ) {
            int max = b.get(0).getFeature().length();
            for(int i = 1; i < b.size();i++){
                if(max <= b.get(i).getFeature().length()){
                    max = b.get(i).getFeature().length();
                }
            }
            return max;
        }
        
        return 0;
    }
    public int findMaxHeight(ArrayList<Expression> a){
        
        return a.size() * 20;
    }
    public MemberInfo getClazz(){
        return mem;
    }
}
