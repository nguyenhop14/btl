
import java.util.ArrayList;

// thong tin cua cac du lieu trong 1 class

public class MemberInfo {
    String name= "";
    String fullname = "";
    String packageName = "";
    ArrayList <Expression> fields = new ArrayList ();
    ArrayList <Expression> methods = new ArrayList ();
    ArrayList <Expression> constructors = new ArrayList ();
    ArrayList <String> listImplements = new ArrayList  ();
    String father="";
    boolean isInterface = false;
    boolean isEnum = false;
    public String getClassName() {
        return fullname;
    }
    public ArrayList <Expression> getVariables() {
        return fields;
    }
    public ArrayList <Expression> getMethods() {
        return methods;
    }
    // kiểm tra quan hệ giữa 2 class 
    public boolean isRelate(MemberInfo a) {
        if (name.equals(a.father) == true ) 
            return true;
        else return false;
        
    }  
    // thông tin cần thiết của 1 class
    public void getFullInfo() {
        System.out.println(fullname);
        System.out.println("Fields: ");
        for ( int i = 0 ; i < fields.size(); i++) {
            System.out.println(fields.get(i).getFullInfo());
        }
        System.out.println("Methods: ");
        for (int i = 0; i < methods.size(); i++) {
            System.out.println(methods.get(i).getFullInfo());
        }
        System.out.println();
        System.out.println();   
    }   
   public void getInfo() {
        System.out.println(packageName);
        System.out.println(fullname);
        System.out.println("Fields: ");
        for ( int i = 0 ; i < fields.size(); i++) {
            System.out.println(fields.get(i).getInfo());
        }
        System.out.println("Methods: ");
        for (int i = 0; i < methods.size(); i++) {
            System.out.println(methods.get(i).getInfo());
        }
        System.out.println("Extends: " + father);
        System.out.println("Implements: ");
        for (int i = 0 ; i < listImplements.size(); i++) {
            System.out.println(listImplements.get(i));
        }      
        System.out.println();
        System.out.println();
    }
}
