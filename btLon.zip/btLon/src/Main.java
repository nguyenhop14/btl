
public class Main {
    public static void main(String[] args){
        Init a = new Init();
        a.start();
    }
}

