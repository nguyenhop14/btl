
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Class {
    ArrayList<Integer> indexBegin = new ArrayList();
    ArrayList<Integer> indexEnd = new ArrayList();
    public void getIndexClass(String text) {
        String regex = "(?<modifier>\\w+)?\\s+(final|abstract)?\\s*(class)\\s+(?<name>\\w+)";
        //group modifier : khớp với final or abstract( có hoặc không),group name: kí tự sau class
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(text);
        while (m.find()) {
            int count = 0;
            int i;
            for (i = m.end(); i < text.length(); i++) {
                if (text.charAt(i)=='{') break;
            }
            int k = i;
            int j;
            for ( j = k; j < text.length(); j++) {
                if (text.charAt(j) == '{') count++;
                if (text.charAt(j) == '}' && count == 1) {
                    indexBegin.add(k);
                    indexEnd.add(j);
                    break;
                } 
                else if (text.charAt(j) == '}')
                    count--;            
            }
        }
    }

    public boolean checkClass(int i) {
        int j;
        for (j = 0 ; j < indexBegin.size(); j++) {
            if ( i > indexBegin.get(j) && i < indexEnd.get(j) ) {
                return true;
            }
        }
        if (j == indexBegin.size()) return false;
        return false;
    }
     public void print(String text) {
           for ( int i = 0 ; i < indexBegin.size(); i++) {
               System.out.println(indexBegin.get(i) + " " + indexEnd.get(i));
               System.out.println(text.charAt(indexBegin.get(i)) + " " + text.charAt(indexEnd.get(i)));
           }
    }

     public int checkInClass(int i) {
         for (int j = indexBegin.size() - 1; j >= 0; j--) {
             if ( i > indexBegin.get(j) && i < indexEnd.get(j)) {
                 return j;
             }
         }
         return -1;
     }
    
}

