
import java.awt.Dimension;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

// phân tích folder thành các file .java
public class Project {
   ArrayList <MemberInfo> l = new ArrayList();  
   public Project (String s) {
       File folder = new File(s);
       this.listFilesForFolder(folder);
       this.print();
   }
   // in ra thông tin của từng thành viên trong folder
   public void print() {
       for ( int i = 0; i < l.size(); i++) {
           l.get(i).getInfo();
       }
   }
   // thêm 1 file.java vào trong mảng
   public void addMember (ArrayList<MemberInfo> a) {
       for (int i = 0; i < a.size(); i++) {
           l.add(a.get(i));
       }
   }
   // triển khai folder
   public void listFilesForFolder( File folder) {
        for (final File f : folder.listFiles()) {
            // Kiểm tra xem f có phải là thư mục hay ko nếu phải thì lại lấy ra các phần tử nhở của nó
            if (f.isDirectory()) {
                listFilesForFolder(f);
            }
            else { 
                AFile file = new AFile();
                // thêm các file trong folder vào
                file.analysFile(f);
                file.getAllMember();             
                addMember(file.members);
                
            }
        }
    }
   // thể hiện thông tin của project trên đồ họa
    public JPanel showProject(){
       return new displayPanel(this);
    }
//    public static void main(String[] args) {
//        
//       AnalysProject a = new AnalysProject ("D:\\java\\Collection\\src\\Exam");
//    }
//    
}


















