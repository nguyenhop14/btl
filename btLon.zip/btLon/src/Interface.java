
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// tim vi tri interface

public class Interface {
    ArrayList<Integer> indexBegin = new ArrayList();
    ArrayList<Integer> indexEnd = new ArrayList();
    public void getIndexInterface(String text) {
        String regex = "(\\w+\\s*)?(interface)\\s+(?<nameInterface>\\w+)"; 
           
        Pattern p = Pattern.compile(regex);// tạo 1 đối tượng regex
        // lớp matcher là phương tiện để so khớp chuỗi dữ liệu ban đầu với đối tượng pattern được tạo ở trên
        Matcher s = p.matcher(text);
        
        while (s.find()) {
            int count = 0;
            int i;
            for (i = s.end(); i < text.length(); i++) {
                if (text.charAt(i)=='{')
                    break;
            }
            int k = i;
            int j;
            for ( j = k; j < text.length(); j++) {
                if (text.charAt(j) == '{') count++;
                if (text.charAt(j) == '}' && count == 1) {
                    indexBegin.add(k);
                    indexEnd.add(j);
                    break;
                } 
                else if (text.charAt(j) == '}') count--;
               
            }
        }
    
    }
    public boolean checkInterface(int i) {
        int j;
        for (j = 0 ; j < indexBegin.size(); j++) {
            if ( i > indexBegin.get(j) && i < indexEnd.get(j) ) {
                return true;
            }
        }
        if (j == indexBegin.size()) return false;
        return false;
    }
     public void print(String text) {
           for ( int i = 0 ; i < indexBegin.size(); i++) {
               System.out.println(indexBegin.get(i) + " " + indexEnd.get(i));
               System.out.println(text.charAt(indexBegin.get(i)) + " " + text.charAt(indexEnd.get(i)));
           }
    }
//     public boolean checkInClass(int i,int index) {
//         if (i > indexBegin.get(index) && i < indexEnd.get(index)) return true;
//         else return false;
//         
//     }
     public int checkInInterface(int i) {
         for (int j = indexBegin.size() - 1; j >= 0; j--) {
             if ( i > indexBegin.get(j) && i < indexEnd.get(j)) {
                 return j;
             }
         }
         return -1;
     }
}
