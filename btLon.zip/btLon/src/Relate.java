

// thể hiện mới quan hệ cha-con
public class Relate {
    private drawShape parent;
    private drawShape child;
    public Relate(drawShape a,drawShape b){
        parent = a;
        child = b;
    }
    public drawShape getChild(){
        return child;
    }
    public drawShape getParent(){
        return parent;
    }
    public void setParent(drawShape a){
        parent = a;
    }
    public void setChild(drawShape a){
        child = a;
    }
}
