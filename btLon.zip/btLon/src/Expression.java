

// class dac tinh
public class Expression {
    String modifier;
    String type;
    String name;
    String fullInfor;
    String getInfo() {
        String str = "";
        
        if (type.equals("public") == false && type.equals("private") == false && type.equals("protected") == false) {
            if (type.equals("static") == false && type.equals("abstract") == false && type.equals("final") == false) {
                str += type + " ";// so sanh lan luot tung chu trong dong, neu ko phai la modifier, dac tinh thi no la loai du lieu cua bien
            }
        }
        str += name + " ";// va sau do la ten bien
        return str;
        
    }
    String getFullInfo() {
        return fullInfor;
    }
    String getFeature() {
        return fullInfor;
    }
}
