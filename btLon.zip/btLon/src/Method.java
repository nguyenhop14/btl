
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
// tim method

public class Method {
    ArrayList<Integer> indexBegin = new ArrayList();
    ArrayList<Integer> indexEnd = new ArrayList();
    public void getIndexMethod(String text) {
        String regex2 = "(?<modifier>public|protected|private)?\\s*(static|final|abstract)?\\s*(static|final|abstract)?\\s*(?<type>(\\w+\\s*(<.*>)?(\\[\\s*\\])?))\\s+(?<nameMethod>(\\w+)\\s*\\((.*\n)*?.*\\))";        
        //modifier: có thể chứa public,..;type:bắt đầu bằng kí tự chữ đến khoảng trắng tiếp;name:bắt đàu là khoảng trắng nếu có, kí tự
        Pattern p2 = Pattern.compile(regex2);
        Matcher s2 = p2.matcher(text);
        int temp = 0;
        while (s2.find(temp)) {
            
            int count = 0;
            int i;
            boolean checkchamphay = false;
            for (i = s2.end(); i < text.length(); i++) {
                if (text.charAt(i)== ';') {
                    checkchamphay = true;
                    temp = s2.end()+1;
                    break;
                }
                if (text.charAt(i)=='{') break;
            }
            if (checkchamphay == false ) {
                int k = i;
                for ( i = k; i < text.length(); i++) {
                    if (text.charAt(i) == '{') count++;
                    if (text.charAt(i) == '}' && count == 1) {
                        indexBegin.add(k);
                        indexEnd.add(i);
                        temp = i+1;
                        break;
                    } 
                    else if (text.charAt(i) == '}') count--;

                }
                
            }          
        }
    }
    // thông tin của method
    public void print(String text) {
           for ( int i = 0 ; i < indexBegin.size(); i++) {
               System.out.println(indexBegin.get(i) + " " + indexEnd.get(i));
               System.out.println(text.charAt(indexBegin.get(i)) + " " + text.charAt(indexEnd.get(i)));
           }
    }
    
    public boolean checkInMethod(int i) {
        int j;
        for (j = 0 ; j < indexBegin.size(); j++) {
            if ( i >= indexBegin.get(j) && i <= indexEnd.get(j) ) {
                return true;
            }
        }
        if (j == indexBegin.size()) return false;
        return false;
    }
    
}
