
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class value {
    ArrayList<Integer> indexBegin = new ArrayList();
    ArrayList<Integer> indexEnd = new ArrayList();
    public void getIndexEnum(String text) {
        String regex = "(\\w+\\s*)?(enum)\\s+(?<nameEnum>\\w+)";  
        //kí tụ à chữ xuất hiện 1 lần, nameEnum(tên biến) là kí tự chữ
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(text);
        
        while (m.find()) {// tìm kiếm các chuỗi con
            
            int count = 0;
            int i;
            for (i = m.end(); i < text.length(); i++) {
                if (text.charAt(i)=='{')
                    break;// gặp { thì thoat khỏi vòng lặp for, bỏ qua { đàu tiên của class
            }
            int k = i;
            for (int j = k; j < text.length(); j++) {
                if (text.charAt(j) == '{') 
                     count++;// dem so {
                if (text.charAt(j) == '}' && count == 1) {
                    //luu vi tri cua k,j de danh dau phan code xu ly
                    indexBegin.add(k);
                    indexEnd.add(j);
                    break;
                } 
                else if (text.charAt(j) == '}') count--;
               
            }
        }
    
    }
    public boolean checkEnum(int i) {
        int j;
        for (j = 0 ; j < indexBegin.size(); j++) {
            if ( i > indexBegin.get(j) && i < indexEnd.get(j) ) {
                return true;
            }
        }
        if (j == indexBegin.size()) return false;
        return false;
    }
    // in ra thông tin của biến 
     public void print(String text) {
           for ( int i = 0 ; i < indexBegin.size(); i++) {
               System.out.println(indexBegin.get(i) + " " + indexEnd.get(i));
               System.out.println(text.charAt(indexBegin.get(i)) + " " + text.charAt(indexEnd.get(i)));
           }
    }

     public int checkInEnum(int i) {
         for (int j = indexBegin.size() - 1; j >= 0; j--) {
             if ( i > indexBegin.get(j) && i < indexEnd.get(j)) {
                 return j;
             }
         }
         return -1;
     }
    
}

