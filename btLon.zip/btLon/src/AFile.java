

import java.util.ArrayList;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AFile {
    ArrayList <MemberInfo> members = new ArrayList();
    ArrayList <MemberInfo> classMember = new ArrayList();
    ArrayList <MemberInfo> interfaceMember = new ArrayList();
    ArrayList <MemberInfo> enumMember = new ArrayList();
    Method indexMethod = new Method();
    Class indexClass = new Class();
    Interface indexInterface = new Interface();
    value indexEnum = new value();
    public ArrayList <MemberInfo> getAllMember() {
        for (int i = 0; i < classMember.size(); i++) {
            members.add(classMember.get(i));
        }
        for ( int i = 0; i < interfaceMember.size(); i++) {
            members.add(interfaceMember.get(i));
        }
        for ( int i = 0; i < enumMember.size(); i++) {
            members.add(enumMember.get(i));
        }
        return members;
        
    }
    public void analysFile(File f) {
        String text = readFile.convertFileToString(f);
        text = readFile.handleFile(text);
        indexMethod.getIndexMethod(text);
        indexClass.getIndexClass(text);
        indexInterface.getIndexInterface(text);

        indexEnum.getIndexEnum(text);
 
        //tìm tên package
        String namePackage = "";
        // chứa kí tự package tên package là kí tự phía sau từ package
        String regexPackage = "(package)\\s+(?<namePackage>.*?);";
        Pattern pPackage = Pattern.compile(regexPackage);
        Matcher mPackage = pPackage.matcher(text);
        if (mPackage.find() == true )
            namePackage = "package " + mPackage.group("namePackage");
        else namePackage = "package default";
        
        //Class and interface and enum
        String regexfull = "(?<modifier>\\w+)?\\s*(?<final>final|abstract|static)?\\s*(?:(?<type>class|interface|enum)\\s+(?<name>\\w+))\\s*(?:(?:(?:extends\\s+(?<nameExtends1>\\w+))|(?:implements\\s+(?<nameImplements1>\\w+(?:\\s*,\\s*\\w+)*)))?\\s*(?:(?:extends\\s+(?<nameExtends2>\\w+))|(?:implements\\s+(?<nameImplements2>\\w+\\s*(?:,\\s*\\w+)*)))?)?";
        Pattern pfull = Pattern.compile(regexfull);
        Matcher mfull = pfull.matcher(text);
        while (mfull.find()) {
            MemberInfo x = new MemberInfo();
            x.packageName = namePackage;
            String str = "";
            if (mfull.group("modifier")!= null) str += mfull.group("modifier") + " ";
            if (mfull.group("final")!= null) str += mfull.group("final") + " ";
            str += mfull.group("type") + " ";
            str += mfull.group("name") + " ";
            x.fullname = str;
            x.name = mfull.group("name");
            if (mfull.group("nameExtends1") != null) x.father = mfull.group("nameExtends1");
            else if (mfull.group("nameExtends2") != null) {
                x.father = mfull.group("nameExtends2");
            }
            if (mfull.group("nameImplements1") != null) {
                String reg = "\\s*,\\s*";
                String [] list = mfull.group("nameImplements1").split(reg);
                for (String s: list) {
                    x.listImplements.add(s);
                }
            }
            else if (mfull.group("nameImplements2") != null) {
                String reg = "\\s*,\\s*";
                String [] list = mfull.group("nameImplements1").split(reg);
                for (String s: list) {
                    x.listImplements.add(s);
                }
            }
            if (mfull.group("type").equals("class") == true)
                classMember.add(x);
            else if (mfull.group("type").equals("interface") == true) {
                x.isInterface = true;
                interfaceMember.add(x);
            }
            else if (mfull.group("type").equals("enum") == true) {
                x.isEnum = true;
                enumMember.add(x);
            }
            
        }
        
        //Variable      
        String regex2 = "(?<modifier>public|protected|private)?\\s*(static|final)?\\s*(static|final)?\\s+(?<type>\\w+(\\s*<.*>)?\\s*(\\[\\s*\\])?)\\s+(?<name>\\w+)\\s*;"; 
        Pattern p2 = Pattern.compile(regex2);
        Matcher m2 = p2.matcher(text);
        while (m2.find()) {

                String reg = "\\s*,\\s*";
                String [] list = m2.group("name").split(reg);           
            if (indexEnum.checkEnum(m2.start()) == true) {
                int temp = indexEnum.checkInEnum(m2.start());
                for (String s: list) {
                    String str = "";
                    Expression x = new Expression();
                    if (m2.group("modifier") != null) {
                        str += m2.group("modifier") + " ";
                        x.modifier = m2.group("modifier");
                    }
                    if (m2.group(2) != null) {
                        str += m2.group(2) + " ";
                    }
                    if (m2.group(3) != null) {
                        str += m2.group(3) + " ";
                    }
                    str += m2.group("type") + " ";
                    x.type = m2.group("type");
                    str += s+ " ";
                    x.name = s;
                    x.fullInfor = str;
                    enumMember.get(temp).fields.add(x);
                }
                
            }
            else if (indexInterface.checkInterface(m2.start())== true) {
                int temp = indexInterface.checkInInterface(m2.start());
                for (String s: list) {
                    String str = "";
                    Expression x = new Expression();
                    if (m2.group("modifier") != null) {
                        str += m2.group("modifier") + " ";
                        x.modifier = m2.group("modifier");
                    }
                    if (m2.group(2) != null) {
                        str += m2.group(2) + " ";
                    }
                    if (m2.group(3) != null) {
                        str += m2.group(3) + " ";

                    }
                    str += m2.group("type") + " ";
                    x.type = m2.group("type");
                    str += s+ " ";
                    x.name = s;
                    x.fullInfor = str;
                    interfaceMember.get(temp).fields.add(x);
                }
            } 
            else if (indexMethod.checkInMethod(m2.start()) == false && indexClass.checkClass(m2.start()) == true) {
                int temp = indexClass.checkInClass(m2.start());
                for (String s: list) {
                    String str = "";
                    Expression x = new Expression();
                    if (m2.group("modifier") != null) {
                        str += m2.group("modifier") + " ";
                        x.modifier = m2.group("modifier");
                    }
                    if (m2.group(2) != null) {
                        str += m2.group(2) + " ";
                    }
                    if (m2.group(3) != null) {
                        str += m2.group(3) + " ";
                    }
                    str += m2.group("type") + " ";
                    x.type = m2.group("type");
                    str += s+ " ";
                    x.name = s;
                    x.fullInfor = str;
                    classMember.get(temp).fields.add(x);
                }
            }
        }          
        //Method
        String regex3 = "(?<modifier>public|protected|private)?\\s*(static|final|abstract)?\\s*(static|final|abstract)?\\s*(?<type>(\\w+\\s*(<.*>)?(\\[\\s*\\])?))\\s+(?<nameMethod>(\\w+)\\s*\\((.*\n)*?.*\\))";
        Pattern p3 = Pattern.compile(regex3);
        Matcher m3 = p3.matcher(text);
        while (m3.find()) {        
            if (indexMethod.checkInMethod(m3.start()) == false){
                String str = "";
                Expression x = new Expression();
                if (m3.group(1) != null) {
                    str += m3.group(1) + " ";
                    x.modifier = m3.group(1);
                }
                if (m3.group(2) != null) {
                    str += m3.group(2) + " ";
                }
                if (m3.group(3) != null) {
                    str += m3.group(3) + " ";
                }
                str += m3.group("type") + " ";
                x.type = m3.group("type");
                str += m3.group("nameMethod") + " ";
                x.name = m3.group("nameMethod");
                x.fullInfor = str;
                if (indexEnum.checkEnum(m3.start()) == true) {
                    int temp = indexEnum.checkInEnum(m3.start());
                    enumMember.get(temp).methods.add(x);
                }
                else if (indexInterface.checkInterface(m3.start())== true) {
                    int temp = indexInterface.checkInInterface(m3.start());
                    interfaceMember.get(temp).methods.add(x);
                } 
                else {
                    int temp = indexClass.checkInClass(m3.start());
                    classMember.get(temp).methods.add(x);
                }
                
            }          
        }            
    }
    // in ra thông tin của các thành phần trong class
    public void getInfo() {
        
        for (int i = 0; i < members.size(); i++) {
            members.get(i).getInfo();
        }
    }
    public void getFullInfo() {
        for (int i = 0; i < members.size(); i++) {
            members.get(i).getFullInfo();
        }
    }
    public static void main(String[] args) {
        File f = new File ("D:\\java\\Tuan05\\src\\cau02\\Student.java");
        AFile file = new AFile();
        file.analysFile(f);
        file.getAllMember();
        file.getInfo();
    }
    
}