
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

// chọn file
public class Init extends javax.swing.JFrame {

    public Init() {
        initComponents();// phương thức đưa ra các giá trị mặc định
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1400, 800));
        setSize(new java.awt.Dimension(0, 0));

        jButton1.setText("Start");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(605, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(148, 148, 148))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jButton1)
                .addContainerGap(626, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        
        // xây dựng JFileChoose trỏ tới thư mục của người dùng
        JFileChooser chooser = new JFileChooser(); 
        // thiết lập thu mục hiện tại
        chooser.setCurrentDirectory(new java.io.File("."));
        //thiết lập việc chỉ chọn 1 thư mục
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        // bắt buộc phải chọn file có trong danh sách
        chooser.setAcceptAllFileFilterUsed(false); 
        //hiện thị hợp thoại open file
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            // chọn 1 đối tượng 
            Project a = new Project (chooser.getSelectedFile().toString());
            System.out.println(chooser.getSelectedFile().toString());
            setContentPane(new JScrollPane(a.showProject()));
            validate();
            setExtendedState(JFrame.MAXIMIZED_BOTH); 

        }       
    }
    public void start() {
           java.awt.EventQueue.invokeLater(new Runnable() {
               public void run() {
                   new Init().setVisible(true);
               }
           });
       }
    
    public static void main(String[] args) {
        Init a = new Init();
        a.start();
    }
    private javax.swing.JButton jButton1;
}
