import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
public class displayPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private ArrayList<drawShape> rect ; 
    private Point2D offset;
    private drawShape selectedShape;
    private ArrayList<Relate> relate;
    private double scale = 1;
    private int Width = 2400;
    private int Height = 1200;
  // tạo nền cho các Shape, phóng to thu nhỏ
    public displayPanel(Project a){
        rect = new ArrayList();
        relate = new  ArrayList();
        //màu nền
        setBackground(Color.PINK);
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        setSize(Width,Height);
        //tạo button tên chụp
        JButton out = new JButton("Chụp");
        out.setPreferredSize(new Dimension(200, 50));
        // tạo chức năng khi click vào button
        out.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                saveComponentAsJPEG();
                JOptionPane.showMessageDialog(null,"Done!");
            }
        });
        // tạo button đảo
        JButton sort = new JButton("Đảo");
        sort.setPreferredSize(new Dimension(200, 50));
        //tạo chức năng
        sort.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e){
                //câu lệnh đảo
                
                
                
                JOptionPane.showMessageDialog(null,"Done!");
            }
        });
        add(out);
        add(sort);
        
        int size = 0;
        int width = 10;
        int height = 100;
        
            for(MemberInfo Class: a.l){
                if(width >= Width - 100 - findMaxWidth(Class.getClassName(), Class.getMethods(), Class.getVariables())){
                    width = 10;
                    height += 400;
                    drawShape rect1 = new drawShape(Class,width,height);
                    addShape(rect1);
                    width += 100 + findMaxWidth(Class.getClassName(), Class.getMethods(), Class.getVariables());   
                } else {
                    if(height == 100){
                        drawShape rect1 = new drawShape(Class,width,height);
                        addShape(rect1); 
                        width += 100 + findMaxWidth(Class.getClassName(), Class.getMethods(), Class.getVariables());
                    } else if((height < Height - 20 - findMaxHeight(Class.getMethods()) - findMaxHeight(Class.getVariables()))){
                        drawShape rect1 = new drawShape(Class,width,height);
                        addShape(rect1);  
                        width += 100 + findMaxWidth(Class.getClassName(), Class.getMethods(), Class.getVariables());
                    } else{
                        Height += 20 + findMaxHeight(Class.getMethods()) + findMaxHeight(Class.getVariables()) + 100;
                        drawShape rect1 = new drawShape(Class,width,height);
                        addShape(rect1);
                        width += 100 + findMaxWidth(Class.getClassName(), Class.getMethods(), Class.getVariables());
                    }  
                }   
                
            }
        for(int i = 0; i < rect.size();i++){
            for(int j = 0; j < rect.size();j++){
                if(rect.get(i).getClazz().isRelate(rect.get(j).getClazz())){
                    Relate re = new Relate(rect.get(i), rect.get(j));
                    relate.add(re);
                }
            }
        }
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e){
                
            }
            @Override
            public void mousePressed(MouseEvent e) {
                for (drawShape p : getRect()) {
                    if (p.contains(e.getPoint())) {
                        // Selected
                        selectedShape = p;
                        offset = new Point2D.Double(e.getX() - p.getBounds().getX(), e.getY() - p.getBounds().getY());
                        break;
                    }
                }
            }

            public void mouseReleased(MouseEvent e) {
                selectedShape = null;
            }
        });
        this.addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseDragged(MouseEvent e) {
                if (selectedShape != null) {

                    Point2D p = new Point2D.Double(e.getX() - offset.getX(), e.getY() - offset.getX());

                    selectedShape.moveTo(p);
                }
                repaint();
            }
            
        });
        
        this.addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                AffineTransform tx = new AffineTransform();
                if (e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
                    //Zoom in
                    if(e.getWheelRotation()<0){
                        scale = (scale > 0.5)? scale - 0.1:scale;
                        
                    }
                    //Zoom out
                    if(e.getWheelRotation()>0){
                        scale = (scale < 1.5)? scale + 0.1:scale;
                        
                    }
                    Point p = e.getPoint();
                    tx.setToIdentity();
                    tx.translate(p.getX(), p.getY());
                    tx.scale(scale, scale);
                    revalidate();
                    repaint();
                }
                
            }

            
        });
        revalidate();
        setVisible(true);
    }
    @Override
    public Dimension getPreferredSize(){
        if(isPreferredSizeSet()){
            return super.getPreferredSize();
        }
        return new Dimension(Width,Height);
    }
    public void addShape(drawShape a){
        rect.add(a);
        repaint();
    }
    public ArrayList<drawShape> getRect(){
        return rect;
    }
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();          
        int w = (int) getWidth();
        int h = (int) getHeight();
        g2.translate(w/2, h/2);
        g2.scale(scale, scale);
        g2.translate(-w/2, -h/2);
        for(Relate re: relate){
            Point2D p1 = new Point2D.Double(re.getParent().getBounds().getCenterX(),re.getParent().getBounds().getCenterY());
            Point2D p2 = new Point2D.Double(re.getChild().getBounds().getCenterX(),re.getChild().getBounds().getCenterY());
            g2.draw(new Line2D.Double(p1,p2));
            int x0 = (int)(p1.getX() + p2.getX()) / 2;
            int y0 = (int)(p1.getY() + p2.getY()) / 2;
            double x1 = p1.getX() - p2.getX();
            double y1 = p1.getY() - p2.getY();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            double theta = Math.atan(y1/x1);
            AffineTransform at = AffineTransform.getTranslateInstance(x0, y0);
            if(x1 < 0){
                at.rotate(theta + Math.toRadians(180));
            }else{
                at.rotate(theta);
            }
            at.scale(2.0, 2.0);
            Shape shape = at.createTransformedShape(createArrow());
            g2.draw(shape);
        }
        for(drawShape a: rect){
            a.paint(this, g2);
        }
        g2.dispose();
    }
    public int findMaxWidth(String a,ArrayList<Expression> b,ArrayList<Expression> c){
        int max = (a.length() <= Max(b))? Max(b):a.length();
        return (max <= Max(c))? Max(c)*6:max * 6;
    }
    public int Max(ArrayList<Expression> b){
        if (b.size() > 0) {
            int max = b.get(0).getFeature().length();
            for(int i = 1; i < b.size();i++){
                if(max <= b.get(i).getFeature().length()){
                    max = b.get(i).getFeature().length();
                }
            }
            return max;
        }
        else return 0;
    }
    public int findMaxHeight(ArrayList<Expression> a){
        return a.size() * 15;
    }
    public void saveComponentAsJPEG() {
            Dimension size = this.getSize();
            BufferedImage myImage = new BufferedImage(size.width, size.height,BufferedImage.TYPE_INT_RGB);
            Graphics2D g2 = myImage.createGraphics();
            this.paint(g2);
            try {
                OutputStream out = new FileOutputStream("output.jpg");
                ImageIO.write(myImage,"jpg",out);
                out.flush();
                out.close();
            } catch (Exception e) {
                System.out.println(e); 
            }
    }
    private Path2D.Double createArrow() {
        int length = 0;
        int barb = 15;
        double angle = Math.toRadians(20);
        Path2D.Double path = new Path2D.Double();
        path.moveTo(-length/2, 0);
        path.lineTo(length/2, 0);
        double x = length/2 - barb*Math.cos(angle);
        double y = barb*Math.sin(angle);
        path.lineTo(x, y);
        x = length/2 - barb*Math.cos(-angle);
        y = barb*Math.sin(-angle);
        path.moveTo(length/2, 0);
        path.lineTo(x, y);
        return path;
    }
    
}
